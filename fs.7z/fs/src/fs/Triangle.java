package fs;

public class Triangle {
	//�Ե����ϵĶ�̬�滮
    //1.f[i][j]��ʾ��i��j�����ߵ����һ�����С·������	
	public static int minimumTotal(int[][] triangle) {
		if (triangle == null) {
			return 0;
		}
		if (triangle.length == 1) {
			return triangle[0][0];
		}
		int row = triangle.length;
		int col = triangle[row-1].length;
		int[][] f = new int[row][col];
	//2.��ʼ��
		for(int i = 0;i<col;++i) {
			f[row-1][i] = triangle[row-1][i];
		}
	//3.ѭ���ݹ����
		for(int i = row - 2;i >= 0;--i) {
			for(int j = 0;j <= i;++j) {
				f[i][j] = Math.min(f[i+1][j],f[i+1][j+1]) + triangle[i][j];
				
			}
		}
	//4.ȷ������ֵ
		return f[0][0];
	}
	//�Զ����µĶ�̬�滮
	//1.f[i][j]��ʾ��0,0�ߵ�i��j����С·������
	public static int minTotal(int[][] triangle) {
		if (triangle == null) {
			return 0;
		}
		if (triangle.length == 1) {
			return triangle[0][0];
		}
		int row = triangle.length;
		int col = triangle[row-1].length;
		int[][] f = new int[row][col];
	//2.��ʼ��
		f[0][0] = triangle[0][0];
		for (int i = 1; i < row; i++) {
	            f[i][0] = f[i - 1][0] + triangle[i][0];
	            f[i][i] = f[i - 1][i - 1] + triangle[i][i];
	        }
	//3.ѭ���ݹ����
		for(int i = 1;i < row; ++i) {
			for(int j = 0 ;j <= i;++j) {
				f[i][j] = Math.min(f[i-1][j],f[i-1][j-1]) + triangle[i][j];
			}
		}
	//4.ȷ������ֵ
		int result = f[row-1][0];
		for(int i = 1;i < col;++i) {
			if (result > f[row-1][i]) {
				result = f[row-1][i];
			}
		}
		return result;
	}
	//���仯���������ǵݹ�ı���
	private int n;
	private int[][] minSum;
	private int[][] triangle;
	private int search(int x,int y) {
		if (x >= n) {
			return 0;
		}
	//���������Ѿ����ʹ���,ֱ�ӷ�����ֵ
		if (minSum[x][y] != Integer.MAX_VALUE) {
			return minSum[x][y];
		}
		minSum[x][y] = Math.min(search(x+1,y), search(x+1,y+1)) + triangle[x][y];
		
		return minSum[x][y];
	}
	public  int minNumberTotal(int[][] triangle) {
		if (triangle == null || triangle.length == 0) {
            return -1;
        }
        if (triangle[0] == null || triangle[0].length == 0) {
            return -1;
        }
        this.n = triangle.length;
        this.triangle = triangle;
        this.minSum = new int[n][n];
        for(int i = 0 ;i < n;++i) {
        	for(int j = 0 ;j < n;++j) {
        		minSum[i][j] = Integer.MAX_VALUE;
        	}
        }
        return search(0,0);
	}
	
	public static void main(String[] args) {
		int[][] triangle = new int[][] {
			{-1},{2,3},{1,-1,-3}
		};
		Triangle a = new Triangle();
		System.out.println(a.minNumberTotal(triangle));
	}
}
