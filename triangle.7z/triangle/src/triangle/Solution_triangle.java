package triangle;
import java.util.Set;

//����Ƕ�̬�滮���й���Ŀ����������triangle

public class Solution_triangle { 
	// jump game
	// version 1 ��̬�滮
	public boolean camJump(int[] A) {
		boolean can[] = new boolean[A.length];
		can[0] = true;
		
		for(int i = 1;i < A.length;i++) {
			for(int j = 0 ;j < i;j++) {
				if(can[j] = true && j + A[j] >= i) {
					can[i] = true;
					break;
				}
			}
		}
		return can[A.length-1];
	}
	//̰���㷨
	public boolean canJumpGreegy(int[] A) {
		if (A == null || A.length == 0) {
			return false;
		}
		int farthest = A[0];
		for(int i = 1;i <A.length;i++) {
			if (i <= farthest && A[i] + i >= farthest) {
				farthest = A[i] + i;
			} 
		}
		return farthest >= A.length-1;
	}
	
	//jump game2
	public int jump(int[] A) {
		int[] steps = new int[A.length];
		
		steps[0] = 0;
		for(int i = 1;i < A.length;i++) {
			steps[i] = Integer.MAX_VALUE;
		}
		
		for(int i = 1;i <A.length;i++) {
			for(int j = 0;j < i;j++) {
				if(steps[j] != Integer.MAX_VALUE && j+A[i] >= i)
					steps[i] = Math.min(steps[i], steps[j]+1);
			}
		}
		return steps[A.length-1];
	}
	
	public int jumpGreedy(int[] A) {
		if (A == null || A.length == 0) {
			return -1;
		}
		int start = 0;
		int end = 0;
		int jumps = 0;
		
		while(end < A.length - 1) {
			jumps++;
			int farthest = end;
			for(int i = start;i<=end;i++) {
				if(A[i] + i > farthest) {
					farthest = A[i] + i;
				}
			}
			start = end + 1;
			end = farthest;
		}
		return jumps;
	}
	
	//�ָ��
	private int getMaxLength(Set<String> dict) {
		int maxLength = 0;
		for(String word : dict) {
			maxLength = Math.max(maxLength, word.length());
		}
		return maxLength;
	}
	
	public boolean wordBreak(String s,Set<String> dict) {
		if (s == null || s.length() == 0) {
			return true;
		}
		
		int maxLength = getMaxLength(dict);
		boolean[] canSegment = new boolean[s.length() + 1];
		
		canSegment[0] = true;
		for(int i = 1;i <=s.length();i++) {
			canSegment[i] = false;
			for(int lastWordLength = 1;
					lastWordLength <= maxLength && lastWordLength <= i;
					lastWordLength++) 
			{
				if (!canSegment[i - lastWordLength]) {
					continue;
				}
				String word = s.substring(i-lastWordLength, i);
				if(dict.contains(word)) {
					canSegment[i] = true;
					break;
				}
				
			}
		}
		return canSegment[s.length()];		
	}
	
	//�����������
	public int longIncreasing(int[] nums) {
		int[] f= new int[nums.length];
		int max = 0;
		for(int i = 0;i < nums.length;i++) {
			f[i] = 1;
			for(int j = 0;j < i;j++) {
				if (nums[j] < nums[i]) {
					f[i] = f[i] > f[j]+1 ? f[i] :f[j] + 1;
				}
			}
			if(f[i] > max) {
				max = f[i];
			}
		}
		return max;
	}
	
	//��С��������
}
